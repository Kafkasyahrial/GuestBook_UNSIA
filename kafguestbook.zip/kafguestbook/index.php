<?php
include 'koneksi.php';

// Proses Simpan Data
if (isset($_POST['submit'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $instansi = mysqli_real_escape_string($koneksi, $_POST['instansi']);
    $tujuan = mysqli_real_escape_string($koneksi, $_POST['tujuan']);
    
    $tanggal = date('Y-m-d');
    $waktu = date('H:i:s');

    $query = "INSERT INTO buku_tamu (nama, instansi, tujuan, tanggal, waktu) 
              VALUES ('$nama', '$instansi', '$tujuan', '$tanggal', '$waktu')";
    
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?status=sukses");
        exit();
    } else {
        echo "<script>alert('Gagal menyimpan data.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BUKU TAMU UNIVERSITAS SIBER ASIA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Tema Warna UNSIA (Biru & Kuning Emas) */
        .bg-unsia-biru {
            background-color: #0B3C5D !important; /* Biru UNSIA */
        }
        .bg-unsia-kuning {
            background-color: #F5A623 !important; /* Kuning UNSIA */
        }
        .btn-unsia-kuning {
            background-color: #F5A623 !important;
            border-color: #F5A623 !important;
            color: #111 !important;
            font-weight: bold;
        }
        .btn-unsia-kuning:hover {
            background-color: #D48A14 !important;
            border-color: #D48A14 !important;
            color: #000 !important;
        }
        .text-unsia-biru {
            color: #0B3C5D !important;
        }
        .border-unsia-biru {
            border-color: #0B3C5D !important;
        }
        .logo-unsia {
            height: 40px;
            width: auto;
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-unsia-biru shadow-sm mb-5">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/28/Logo_Universitas_Siber_Asia.png" alt="Logo UNSIA" class="logo-unsia me-2" onerror="this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6A6GgMv_Oun5b8IitRmdC_96O_CjS3I08AQ&s'">
            <span>BUKU TAMU UNIVERSITAS SIBER ASIA</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="index.php"><i class="bi bi-person-plus-fill me-1"></i> Isi Buku Tamu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="riwayat.php"><i class="bi bi-list-stars me-1"></i> Lihat Riwayat Tamu</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                
                <?php if (isset($_GET['status']) && $_GET['status'] == 'sukses'): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm border-start border-success border-4" role="alert">
                        <strong>Berhasil disimpan!</strong> Terima kasih telah mengisi buku tamu Universitas Siber Asia.
                        <a href="riwayat.php" class="alert-link d-block mt-1 text-unsia-biru"><i class="bi bi-arrow-right-short"></i> Lihat daftar riwayat tamu di sini</a>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="card shadow border-0 p-2">
                    <div class="card-header bg-unsia-biru text-white fw-bold text-center rounded d-flex align-items-center justify-content-center gap-2 py-3">
                        <i class="bi bi-pencil-square fs-5"></i>
                        <span>FORMULIR TAMU DATANG</span>
                    </div>
                    <div class="card-body">
                        <form action="index.php" method="POST">
                            <div class="mb-3">
                                <label for="nama" class="form-label fw-semibold">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama" name="nama" required placeholder="Masukkan nama lengkap">
                            </div>
                            <div class="mb-3">
                                <label for="instansi" class="form-label fw-semibold">Instansi / Lembaga Asal</label>
                                <input type="text" class="form-control" id="instansi" name="instansi" required placeholder="Nama instansi/perusahaan/sekolah">
                            </div>
                            <div class="mb-3">
                                <label for="tujuan" class="form-label fw-semibold">Tujuan Kedatangan</label>
                                <textarea class="form-control" id="tujuan" name="tujuan" rows="4" required placeholder="Alasan atau keperluan kunjungan ke kampus UNSIA"></textarea>
                            </div>
                            <div class="d-grid mt-4">
                                <button type="submit" name="submit" class="btn btn-unsia-kuning btn-lg shadow-sm text-uppercase">
                                    <i class="bi bi-send-fill me-2"></i>Simpan Data Tamu
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>