<?php
include 'koneksi.php';

// Fitur Pencarian
$search = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($koneksi, $_GET['search']);
    $query_select = "SELECT * FROM buku_tamu WHERE nama LIKE '%$search%' OR instansi LIKE '%$search%' ORDER BY id DESC";
} else {
    $query_select = "SELECT * FROM buku_tamu ORDER BY id DESC";
}
$result = mysqli_query($koneksi, $query_select);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Kunjungan - UNIVERSITAS SIBER ASIA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Tema Warna UNSIA (Biru & Kuning Emas) */
        .bg-unsia-biru {
            background-color: #0B3C5D !important;
        }
        .btn-unsia-kuning {
            background-color: #F5A623 !important;
            border-color: #F5A623 !important;
            color: #111 !important;
            font-weight: bold;
        }
        .btn-unsia-kuning:hover {
            background-color: #D48A14 !important;
            border-color: #D48A14 !important;
            color: #000 !important;
        }
        .badge-unsia-biru {
            background-color: #0B3C5D !important;
            color: #fff;
        }
        .logo-unsia {
            height: 40px;
            width: auto;
        }
    </style>
</head>
<body class="bg-light">

   <nav class="navbar navbar-expand-lg navbar-dark bg-unsia-biru shadow-sm mb-5">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/28/Logo_Universitas_Siber_Asia.png" alt="Logo UNSIA" class="logo-unsia me-2" onerror="this.src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6A6GgMv_Oun5b8IitRmdC_96O_CjS3I08AQ&s'">
            <span>BUKU TAMU UNIVERSITAS SIBER ASIA</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="index.php"><i class="bi bi-person-plus-fill me-1"></i> Isi Buku Tamu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold" href="riwayat.php"><i class="bi bi-list-stars me-1"></i> Lihat Riwayat Tamu</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container">
        <div class="card shadow border-0">
            <div class="card-header bg-unsia-biru text-white d-flex justify-content-between align-items-center p-3">
                <h5 class="mb-0 fw-bold"><i class="bi bi-journal-text me-2"></i>Daftar Riwayat Kunjungan Tamu</h5>
                <span class="badge bg-warning text-dark fs-6 fw-bold"><?php echo mysqli_num_rows($result); ?> Total Tamu</span>
            </div>
            <div class="card-body p-4">
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <form action="riwayat.php" method="GET">
                            <div class="input-group shadow-sm">
                                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama atau instansi..." value="<?php echo htmlspecialchars($search); ?>">
                                <button class="btn btn-unsia-kuning" type="submit">
                                    <i class="bi bi-search me-1"></i> Cari
                                </button>
                                <?php if (!empty($search)): ?>
                                    <a href="riwayat.php" class="btn btn-danger">Reset</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle border table-bordered">
                        <thead class="table-dark text-center">
                            <tr>
                                <th style="width: 5%">No</th>
                                <th style="width: 25%">Nama Lengkap</th>
                                <th style="width: 20%">Instansi / Lembaga</th>
                                <th style="width: 30%">Tujuan Kedatangan</th>
                                <th style="width: 20%">Waktu Kedatangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if (mysqli_num_rows($result) > 0) {
                                $no = 1;
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $tgl_format = date('d-m-Y', strtotime($row['tanggal']));
                                    $waktu_format = date('H:i', strtotime($row['waktu']));
                                    
                                    echo "<tr>";
                                    echo "<td class='text-center fw-bold'>{$no}</td>";
                                    echo "<td class='fw-bold text-dark text-capitalize'>{$row['nama']}</td>";
                                    echo "<td class='text-center'><span class='badge badge-unsia-biru px-3 py-2 fs-7'>{$row['instansi']}</span></td>";
                                    echo "<td>" . nl2br(htmlspecialchars($row['tujuan'])) . "</td>";
                                    echo "<td class='text-center'><small class='text-muted'><i class='bi bi-calendar3 me-1'></i>{$tgl_format}<br><i class='bi bi-clock me-1'></i>{$waktu_format} WIB</small></td>";
                                    echo "</tr>";
                                    $no++;
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center py-5 text-muted'><i class='bi bi-folder-x fs-1 d-block mb-2'></i>Tidak ada data riwayat tamu yang cocok atau ditemukan.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>